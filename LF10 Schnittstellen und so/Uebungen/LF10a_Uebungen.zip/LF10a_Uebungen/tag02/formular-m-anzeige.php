<?php
$name =   $_POST['vorname'];
$geheim = $_POST['password'];
echo "Hallo ". $name;
echo ", hier bist du richtig. ";
echo "Dein Passwort $geheim ist mir jetzt auch bekannt";
?>