<?php

   function cgi_param ($feld, $default) {
      // Variable zun�chst auf Default-Wert setzen
      $var = $default;
      // HTTP-Methode ermitteln
      $meth = $_SERVER['REQUEST_METHOD'];
      if ($meth == "GET") {
         if (isset($_GET[$feld]) && $_GET[$feld] != "") {
            $var = $_GET[$feld];
         }
      } elseif ($meth == "POST") {
         if (isset($_POST[$feld]) && $_POST[$feld] != "") {
            $var = $_POST[$feld];
         }
      }
      // Ermittelten Wert zur�ckgeben
      return $var;
   }
   
    // Verbindungsparameter
    $host = "localhost";
    $user = "winuser";
    $pass = "4dm1nd4t";
    $db   = "gewinnspiel";
    
    // Verbindung zum MySQL-Server herstellen
    $conn = mysql_connect ($host, $user, $pass);
    
    // Datenbank ausw�hlen
    mysql_select_db ($db);

?>
<html>
<head>
<title>Gewinnspiel - Auswertung</title>
</head>
<body>
<h1>Gewinnspiel - Auswertung</h1>
<?php
    // Nummern der richtigen Antworten speichern
    $fr_query = mysql_query ("select fr_korrekt from gw_fragen order by fr_id asc");
    $korrekt = array();
    while (list ($fr_korrekt) = mysql_fetch_row ($fr_query)) {
       array_push ($korrekt, $fr_korrekt);
    }
    
    // Alle Teilnehmer ermitteln
    $tn_query = mysql_query ("select tn_id from gw_teilnehmer");
    $teilnehmer = array();
    while (list ($tn_id) = mysql_fetch_row ($tn_query)) {
       array_push ($teilnehmer, $tn_id);
    }
    
    // F�r jeden Teilnehmer herausfinden, 
    // ob er alles richtig beantwortet hat
    $korr_teilnehmer = array();
    foreach ($teilnehmer as $tn_id) {
       // Vermutung: Alles richtig
       $richtig = 1;
       // Alle Antworten des Teilnehmers durchlaufen
       $tl_query = mysql_query ("select tl_frg, tl_antw from gw_teilnahme where tl_tln=$tn_id order by tl_frg asc");
       for ($i = 0; list ($tl_frag, $tl_antw) = mysql_fetch_row ($tl_query); $i++) {
          // Falsche Antwort?
          if ($tl_antw != $korrekt[$i]) {
             // Also nicht alles richtig
             $richtig = 0;
          }
       }
       
       // Alles richtig?
       if ($richtig) {
          array_push ($korr_teilnehmer, $tn_id);
       }
    }
?>
Folgende Teilnehmer haben alle Fragen richtig beantwortet:<br />
<br />
<table border="2" cellpadding="4">
<tr>
<th>Teilnehmer</th>
<th>E-Mail</th>
<th>Lieblingsstadt</th>
</tr>
<?php

    // Die Lieblingsst�dte
    $staedte = array ("Paris", "London", "Istanbul", "Rom");
    
    // Ausgabe aller korrekten Einsendungen
    foreach ($korr_teilnehmer as $kt) {
       $kt_query = mysql_query ("select tn_uname, tn_email, tn_interest from gw_teilnehmer where tn_id=$kt");
       list ($tn_uname, $tn_email, $tn_interest) = mysql_fetch_row ($kt_query);
       echo "<tr>\n";
       echo "<td>$tn_uname</td>\n";
       echo "<td>$tn_email</td>\n";
       echo "<td>".$staedte[$tn_interest - 1]."</td>\n";
       echo "</tr>\n";
    }
    
?>
</table>
<br />
<?php

    // Den Gewinner "ziehen"
    srand ((double)microtime() * 10000);
    $gnummer = rand (0, sizeof ($korr_teilnehmer) - 1);
    $gewinner = $korr_teilnehmer[$gnummer];
    
    // und ausgeben
    $gw_query = mysql_query ("select tn_uname, tn_email from gw_teilnehmer where tn_id=$gewinner");
    list ($tn_uname, $tn_email) = mysql_fetch_row ($gw_query);
    echo ("Gewonnen hat: <b>$tn_uname</b> (<a href=\"mailto:$tn_email\">$tn_email</a>)");
    
?>
</body>
</html>