<?php

   function cgi_param ($feld, $default) {
      // Variable zun�chst auf Default-Wert setzen
      $var = $default;
      // HTTP-Methode ermitteln
      $meth = $_SERVER['REQUEST_METHOD'];
      if ($meth == "GET") {
         if (isset($_GET[$feld]) && $_GET[$feld] != "") {
            $var = $_GET[$feld];
         }
      } elseif ($meth == "POST") {
         if (isset($_POST[$feld]) && $_POST[$feld] != "") {
            $var = $_POST[$feld];
         }
      }
      // Ermittelten Wert zur�ckgeben
      return $var;
   }
   
   $fehler = cgi_param ("fehler", 0);
   
?>
<html>
<head>
<title>Gewinnspiel</title>
<meta http-equiv="Content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<h1>Gewinnspiel</h1>
<p>Beantworten Sie die folgenden Fragen und gewinnen Sie eine All-Inclusive-Wochenendreise in eine europ&auml;ische Gro&szlig;stadt aus unserem Angebot!</p>
<?php

   if ($fehler) {
   
?>
<p><font color="#FF0000">Bitte alles vollst&auml;ndig ausf&uuml;llen!</font></p>
<?php

   }
   
?>
<form action="teilnahme.php" method="post">
<?php

    // Verbindungsparameter
    $host = "localhost";
    $user = "winuser";
    $pass = "4dm1nd4t";
    $db   = "gewinnspiel";
    
    // Verbindung zum MySQL-Server herstellen
    $conn = mysql_connect ($host, $user, $pass);
    
    // Datenbank ausw�hlen
    mysql_select_db ($db);
    
    // Abfrage senden
    $fr_query = mysql_query ("select fr_id, fr_frage from gw_fragen order by fr_id asc");
    
    // Zeilen lesen und Fragen stellen
    while (list ($fr_id, $fr_frage) = mysql_fetch_row ($fr_query)) {
       // Fragetext ausgeben
       echo "<b>$fr_id. $fr_frage</b><br /><br />";
       // Antworten holen
       $an_query = mysql_query ("select an_antwort, an_text from gw_antworten where an_frage=$fr_id order by an_antwort asc");
       // Radio-Buttons und Antworten ausgeben
       while (list ($an_antwort, $an_text) = mysql_fetch_row ($an_query)) {
          echo "<input type=\"radio\" name=\"f$fr_id\" value=\"$an_antwort\" /> $an_text<br />";
       }
       echo "<br />";
    }
    
?>
<h2>Pers&ouml;nliche Angaben</h2>
<table border="0" cellpadding="4">
<tr>
<td>Benutzername:</td>
<td colspan="3"><input type="text" name="uname" />
</tr>
<tr>
<td>E-Mail:</td>
<td colspan="3"><input type="text" name="email" />
</tr>
<tr>
<td colspan="4">Welche dieser St&auml;dte w&uuml;rden Sie bald am liebsten besuchen?</td>
</tr>
<tr>
<td><input type="radio" name="wish" value="1" />Paris</td>
<td><input type="radio" name="wish" value="2" />London</td>
<td><input type="radio" name="wish" value="3" />Istanbul</td>
<td><input type="radio" name="wish" value="4" />Rom</td>
</tr>
</table>
<input type="submit" value="Abschicken" />
</form>
</body>
</html>