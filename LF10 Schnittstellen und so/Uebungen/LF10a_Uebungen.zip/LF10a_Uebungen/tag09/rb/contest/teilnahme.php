<?php

   function cgi_param ($feld, $default) {
      // Variable zun�chst auf Default-Wert setzen
      $var = $default;
      // HTTP-Methode ermitteln
      $meth = $_SERVER['REQUEST_METHOD'];
      if ($meth == "GET") {
         if (isset($_GET[$feld]) && $_GET[$feld] != "") {
            $var = $_GET[$feld];
         }
      } elseif ($meth == "POST") {
         if (isset($_POST[$feld]) && $_POST[$feld] != "") {
            $var = $_POST[$feld];
         }
      }
      // Ermittelten Wert zur�ckgeben
      return $var;
   }
   
    // Verbindungsparameter
    $host = "localhost";
    $user = "winuser";
    $pass = "4dm1nd4t";
    $db   = "gewinnspiel";
    
    // Verbindung zum MySQL-Server herstellen
    $conn = mysql_connect ($host, $user, $pass);
    
    // Datenbank ausw�hlen
    mysql_select_db ($db);
    
    // Vermutung: Alles korrekt ausgef�llt
    $korrekt = 1;
    
    // Formulardaten lesen
    for ($i = 1; $i <= 4; $i++) {
       $antwort[$i] = cgi_param ("f$i", 0);
       if ($antwort[$i] == 0) {
          $korrekt = 0;
       }
    }
    $uname = cgi_param ("uname", "");
    $email = cgi_param ("email", "");
    $interest = cgi_param ("wish", 0);
    if ($uname == "" || $email == "" || $interest == 0) {
       $korrekt = 0;
    }
    
    // Etwas nicht ausgef�llt?
    if (!$korrekt) {
       header ("Location: spiel.php?fehler=1");
    } else {
       // Infos in die Datenbank schreiben
       mysql_query ("insert into gw_teilnehmer (tn_uname, tn_email, tn_interest) values (\"$uname\", \"$email\", $interest)");
       if (mysql_affected_rows() == 0) {
          header ("Location: error.html");
       } else {
          // Teilnehmer-ID ermitteln
          $query = mysql_query ("select tn_id from gw_teilnehmer where tn_email=\"$email\"");
          list ($id) = mysql_fetch_row ($query);
          for ($i = 1; $i <= 4; $i++) {
             mysql_query ("insert into gw_teilnahme values ($id, $i, $antwort[$i])");
             if (mysql_affected_rows() == 0) {
                header ("Location: error.html");
             }
          }
       }
    }
   
?>
      
<html>
<head>
<title>Gewinnspiel</title>
<meta http-equiv="Content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<h1>Vielen Dank, <?php echo ($uname); ?>!</h1>
<p>Wir freuen uns, dass Sie an unserem Gewinnspiel teilgenommen haben.<br />
Unter allen richtigen Einsendungen verlosen wir am 01.09.2005 die Reise.<br />
<br />
Der Gewinner wird per E-Mail benachrichtigt.</p>
</body>
</html>