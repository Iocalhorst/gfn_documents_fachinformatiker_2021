<html>
  <head>
    <title>Reiseb&uuml;ro: Auswahl</title>
    <link rel="stylesheet" type="text/css" href="main.css" />
  </head>
  <body>
    <table border="0" width="750" align="center">
    <tr>
    <td>
    &nbsp;<br /><div align="center"><img src="logo.gif" width="480" height="80" alt="EuroCityTravel" /></div><br />
    <!-- Einfache Navigationsleiste -->
    [
    Home
    |
    <a href="auskunft.php">Reisesuche</a>
    |
    <a href="info.php">Touristeninfo</a>
    |
    <a href="login.php">Anmeldung</a>
    |
    <a href="gast.php">G&auml;stebuch</a>
    |
    <a href="forum.php">Forum</a>
    ]
    <!-- Ende der Navigationsleiste> -->
    <h2>Herzlich willkommen!</h2>
    Wir sind Ihr Online-Reiseb&uuml;ro, spezialisiert auf Flugreisen in europ&auml;ische Metropolen und die entsprechenden Hotelaufenthalte. Wir w&uuml;nschen Ihnen einen angenehmen Aufenthalt - auf unserer Website und in Ihrem Urlaub!
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    &nbsp;
    </td>
    </tr>
    </table>
  </body>
</html>