<html>
  <head>
    <title>Reiseb&uuml;ro</title>
  </head>
  <body>
    <h1>Reiseb&uuml;ro</h1>
    <!-- Einfache Navigationsleiste -->
    [
    Home
    |
    <a href="auskunft.php">Reisesuche</a>
    |
    <a href="info.php">Touristeninfo</a>
    |
    <a href="login.php">Anmeldung</a>
    |
    <a href="gast.php">G&auml;stebuch</a>
    |
    <a href="forum.php">Forum</a>
    ]
    <!-- Ende der Navigationsleiste> -->
    <h2>Herzlich willkommen!</h2>
    Wir sind Ihr Online-Reiseb&uuml;ro, spezialisiert auf Flugreisen in europ&auml;ische Metropolen und die entsprechenden Hotelaufenthalte. Wir w&uuml;nschen Ihnen einen angenehmen Aufenthalt - auf unserer Website und in Ihrem Urlaub!
  </body>
</html>