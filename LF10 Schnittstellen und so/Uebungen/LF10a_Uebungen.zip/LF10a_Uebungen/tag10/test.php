<?php
$var = 45;
echo $var; 
settype($var, "integer");
echo "<h1>_</h1><p>Der Typ der Variable ist: <h1> _" . gettype($var) . "</h1></p>";
#var_dump($var); //-> strukturierte Info zum Objekt/zur Variable!

?>