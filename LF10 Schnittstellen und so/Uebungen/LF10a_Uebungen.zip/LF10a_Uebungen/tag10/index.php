<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Startseite LF10a</title>
</head>
<body>
<h1>Lernfeld 10a</h1>
<h2>1. Woche</h2>
<p>Montag: erste Schritte mit php-Skript. 
Bla bla bla</p>
<ul>
	<li>XAMPP installieren, Datenbank- und Webserver starten</li>
	<li><a href="tag01/uebung1.php">uebung1.php</a></li>
	<li><a href="tag01/uebung2.php">uebung2.php</a></li>
</ul>

<p>Dienstag: mit php rechnen, String Verkettung</p>
<ul>
	<li><a href="tag02/uebung3.php">uebung3</a>  Inkrement, Dekrement, Nachkommastellen</li>
	<li><a href="tag02/uebung4.php">uebung4</a>  eigene Funktionen, Datentypen, Datumsfunktionen</li>
	<li>Das <a href="tag02/formular1.html">Formular</a> mit 2 Eingabefeldern ruft das Skript 
		<a href="tag02/formular-m-anzeige.php">formular-m-anzeige.php</a> auf.</li>
	<li><a href="tag02/affenformular.php">Affenformular ruft sich selbst auf</a></li>
</ul>
<p>Mittwoch: Dateizugriff, Schleifen, Variable Scope (Variablen Gültigkeitsbereich)</p>
<ul>
	<li><a href="tag03/affenformular2.php">Affenformular mit detailierter Eingabeprüfung</a> noch mit Fehler in Zeile 18</li>
	<li><a href="tag03/besucher.php">Besucherzähler mit Dateizugriff</a></li>
	<li><a href="tag03/schleife.php">While- ,Do-While- und for-Schleife</a></li>
	<li><a href="tag03/uhrzeit.php">uhrzeit.php</a> und Division durch 0</li>
	<li><a href="tag03/scope.php">scope.php</a> Variable Scope</li>
</ul>
<p>Donnerstag: Kontrollstruktur Switch, Array, Session-Array</p>
<ul>
	<li><a href="tag04/monat_tage.php">monat_tage.php</a> Wieviel Tage hat der Monat (Select List)</li>
	<li><a href="tag04/array1.php">array1.php</a> Array anlegen und auslesen mit foreach-Schleife</li>
	<li><a href="tag04/session.php">session.php</a> Session-Array</li>
	<li><a href="tag04/aufgabesession.php">aufgabesession.php</a> Anmeldung mit festem Wert im Skript</li>
	<li><a href="tag04/anmelden1.php">anmelden</a> Anmeldeskript mit Session und Prüfung der inaktiven Zeit 
		(60 * 30) = 30 Minuten</li>
</ul>
<hr>

<p>Freitag: Datenbank Zugriff mit php</p>
<ul>
	<li><a href="adressbuch">Adressbuch</a> es wird im Browser auf den Ordner adressbuch verwiesen<br>
		sodass die index.php Datei aufgerufen wird!</li>
	<li><a href="adressbuch/aendern.php">aendern.php</a> Standort: Eintrag in der Datenbank ändern</li>
	<li><a href="adressbuch/einfuegen.php">einfuegen.php</a> Einfügen mit <b>"URL?vorname=vname&nachname=nname"</b></li>
	<br>
	<li><a href="rechnen/index.html">Rechner</a> ein einfacher Rechner mit Grundrechenarten</li>
</ul>
</body>
</html>