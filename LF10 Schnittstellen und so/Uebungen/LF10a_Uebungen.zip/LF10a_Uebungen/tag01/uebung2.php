<h2>Serverumgebung</h2>
<?php
echo "PHP_SELF: ". $_SERVER['PHP_SELF'] . "<br>";
echo "REMOTE_ADDR: ". $_SERVER['REMOTE_ADDR'] . "<br>";
echo "HTTP_HOST: ". $_SERVER['HTTP_HOST'] . "<br>";
//echo "REDIRECT_URL: ". $_SERVER['REDIRECT_URL'] . "<br>";

echo 5 / 3 ;
?>